import Index from "./Pages/Index/Index"; 
import Cart from "./Pages/Cart/Cart";
const routes = [
  { path: "/", element: <Index /> },
  { path: "/cart", element: <Cart /> },
 
];

export default routes;
